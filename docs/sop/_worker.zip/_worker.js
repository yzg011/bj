﻿export default {
  async fetch(request, env, ctx) {
    const MEMOS_BASE = "https://ss.z2m.store";
    const MEMOS_TOKEN = env.MEMOS_TOKEN;

    // 跨域预检
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
      });
    }

    if (!MEMOS_TOKEN) {
      return new Response(JSON.stringify([]), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    try {
      const res = await fetch(`${MEMOS_BASE}/api/v1/memos?pageSize=1000`, {
        headers: { Authorization: `Bearer ${MEMOS_TOKEN}` },
      });
      const raw = await res.json();
      const rawList = Array.isArray(raw.memos) ? raw.memos : [];

      // 处理图片路径，补全域名、移除缩略参数
      const fixImageUrl = (src) => {
        let url = src;
        // 相对路径拼接域名
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
          url = `${MEMOS_BASE}${url.startsWith("/") ? "" : "/"}${url}`;
        }
        // 删除缩略后缀
        url = url.replace(/\?thumbnail=true$/, "");
        return url;
      };

      // 1. 提取Markdown内容里的图片 ![]()
      const extractMdImages = (text) => {
        const reg = /!\[(.*?)\]\((.*?)\)/g;
        const list = [];
        let match;
        while ((match = reg.exec(text)) !== null) {
          list.push({
            alt: match[1],
            src: fixImageUrl(match[2]),
          });
        }
        return list;
      };

      // 2. 提取API attachments 附件图片（重点新增）
      const extractAttachImages = (attachments) => {
        const list = [];
        if (!Array.isArray(attachments)) return list;
        attachments.forEach((att) => {
          if (att.type && att.type.startsWith("image/")) {
            // memos附件标准路径
            const path = `/file/attachments/${att.uid}/${att.filename}`;
            list.push({
              alt: att.filename,
              src: fixImageUrl(path),
            });
          }
        });
        return list;
      };

      const cleanPlainText = (text) => {
        return text.replace(/!\[.*?\]\(.*?\)/g, "").trim();
      };

      const buildId = (msTs) => {
        const d = new Date(msTs);
        const pad = (n) => n.toString().padStart(2, "0");
        const y = d.getFullYear();
        const m = pad(d.getMonth() + 1);
        const day = pad(d.getDate());
        const h = pad(d.getHours());
        const min = pad(d.getMinutes());
        return `${y}-${m}-${day}-${y}-${m}-${day}t${h}${min}`;
      };

      const targetList = rawList.map((item) => {
        const msTimestamp = item.createTime;
        const plain = cleanPlainText(item.content);
        // 合并两种图片：正文md图片 + 附件图片
        const mdImgs = extractMdImages(item.content);
        const attImgs = extractAttachImages(item.attachments);
        const allImages = [...mdImgs, ...attImgs];

        return {
          id: buildId(msTimestamp),
          published: msTimestamp,
          html: `<p>${plain}</p>`,
          images: allImages,
          searchText: plain,
        };
      });

      return new Response(JSON.stringify(targetList, null, 2), {
        headers: {
          "Content-Type": "application/json;charset=utf-8",
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "s-maxage=300",
        },
      });
    } catch (err) {
      return new Response(JSON.stringify([]), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }
  },
};